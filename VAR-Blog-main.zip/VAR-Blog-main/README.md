# VAR-Blog
Some code for a blog about VAR models
